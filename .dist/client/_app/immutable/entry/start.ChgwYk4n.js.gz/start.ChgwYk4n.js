import{a as t}from"../chunks/entry.C6g5XbfP.js";export{t as start};
